<?php
# Version 1.0.0
$lang['name_api']        = 'API Name';
$lang['token_api']        = 'Token';
$lang['new_token']        = 'New Token';
$lang['new_user_api']        = 'New Token';
$lang['api_crm']        = 'API CRM';
$lang['api_crm_manager']        = 'API CRM Manager';
