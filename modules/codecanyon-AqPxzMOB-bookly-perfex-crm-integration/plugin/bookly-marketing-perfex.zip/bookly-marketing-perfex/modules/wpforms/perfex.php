<?php
class Rednumber_Marketing_CRM_Frontend_Perfex_WPForms{
	private static $add_on ="perfex"; 
	private static $form ="wpforms"; 
	private $datas_submits= array(); 
	function __construct(){
		add_action('wpforms_process_complete', array($this,'submit_form'),11,4);
		//add_action( 'crm_marketing_sync_'.self::$form."_".self::$add_on,array($this,"sync"));
	}
	function set_datas_submits($key,$value){
		$datas_submits= $this->datas_submits;
		$datas_submits[ $key ] = $value;
		$this->datas_submits = $datas_submits;
	}
	function sync($form_id){
		$options = get_option("crm_marketing_".self::$add_on,array("api"=>""));
		$datas = Rednumber_Marketing_CRM_Database::get_datas(self::$form,self::$add_on,$form_id);
		$total_succsess = 0;
		$total_error = 0;
		if( is_array($datas) && count($datas) > 0 && $options["api"] != "" ){ 
			$submissions = wpforms()->entry->get_entries(array( 'form_id' => $form_id ));
			foreach( $submissions as $submission ){
				$submission = (array) $submission;
				$fields = json_decode( $submission["fields"],true);
				 unset($submission["fields"]);
				 foreach( $fields as $id => $value ){
				 	$submission[ (string) $id] = $value["value"];
				 }
				 $response = $this->add_submit($datas,$submission);
				 if( $response ) {
						if( $response["status"] ){ 
							$total_succsess++;
						}else{
							$total_error++;
						}
					}else{
						$total_error++;
					}
			}
			printf( esc_html__( 'Success: %s Error: %s', 'crm-marketing' ),$total_succsess ,$total_error );
		}
	}
	function submit_form($fields, $entry, $form_data, $entry_id  ){	
		$form_id = $entry["id"];
		$options = get_option("crm_marketing_".self::$add_on,array("api"=>""));
		$datas = Rednumber_Marketing_CRM_Database::get_datas(self::$form,self::$add_on,$form_id);
		if( is_array($datas) && count($datas) > 0 && $options["api"] != "" ){
			$this->add_submit($datas,$fields,$entry,$form_data,$entry_id);
		}
	}
	function add_submit( $datas, $fields, $entry, $form_data, $entry_id ){ 
		$datas = $datas[0];
		$form_id = $entry["id"];
		$api = new Rednumber_Marketing_CRM_Perfex_API();
		foreach( $datas as $key=> $data ){
			if( isset($data["enable"]) && $data["enable"] == "on"){  
				$submits =  $this->get_submits($data, $fields, $entry, $form_data, $entry_id,$key);
				$response = $api->add_submit($key,$submits);
				$response = json_decode($response,true);
				
				if( $response["status"] ){
					$this->set_datas_submits("current_".$key,$response["id"]);
					Rednumber_Marketing_CRM_Logs::add($key.": Added ID ".$response["id"],"Send datas",self::$form,self::$add_on,$form_id);
				}else{
					Rednumber_Marketing_CRM_Logs::add($key." ERROR: ".array_shift(array_values($response["message"])),"ERROR",self::$form,self::$add_on,$form_id);
				}
			}
		}
		return $response;
	}
	function get_submits($datas,  $fields, $entry, $form_data, $entry_id , $type=null){
		$submits = array();
		$plugins = array("plugin"=>self::$form,"datas"=>$datas,"form"=>$form_data,"type"=>$type,"add"=>$this->datas_submits,"add_ons"=>array("fields"=>$fields,"entry_id"=>$entry_id));
		$submits_new = Rednumber_Marketing_CRM_backend::get_datas_contact_form($plugins);
		$submits = Rednumber_Marketing_CRM_Perfex::cover_data_to_api($submits_new,$type,$form_data,self::$form);
		return $submits;
	}
}
new Rednumber_Marketing_CRM_Frontend_Perfex_WPForms;